function getData(){
    var request=new XMLHttpRequest()
    request.open("get","https://restcountries.com/v3.1/name/bharat")
    request.send()

    request.addEventListener("load",()=>{
        var [data]=JSON.parse(request.responseText)           //Response Text is for JSON
        // document.write(data)
        document.getElementById("official").innerHTML = data.name.official
        document.getElementById("capital").innerHTML = data.capital
        document.getElementById("flag").src = data.flags.svg
        document.getElementById("land").innerHTML = data.landlocked
        document.getElementById("border").innerHTML = data.borders
        document.getElementById("area").innerHTML = data.area
        document.getElementById("population").innerHTML = data.population
        document.getElementById("maps").href = data.maps.googleMaps
        document.getElementById("region").innerHTML = data.region
        document.getElementById("sub").innerHTML = data.subregion
        document.getElementById("time").innerHTML = data.timezones
    })
}
getData()

function fun(){
    var name=document.getElementById("search").value
    request=new XMLHttpRequest()
    request.open("get","https://restcountries.com/v3.1/name/"+name)
    request.send()

    request.addEventListener("load",()=>{
        var [data]=JSON.parse(request.responseText)
        document.getElementById("official").innerHTML = data.name.official
        document.getElementById("capital").innerHTML = data.capital
        document.getElementById("flag").src = data.flags.svg
        document.getElementById("land").innerHTML = data.landlocked
        document.getElementById("border").innerHTML = data.borders
        document.getElementById("area").innerHTML = data.area
        document.getElementById("population").innerHTML = data.population
        document.getElementById("maps").href = data.maps.googleMaps
        document.getElementById("region").innerHTML = data.region
        document.getElementById("sub").innerHTML = data.subregion
        document.getElementById("time").innerHTML = data.timezones
    })

} 